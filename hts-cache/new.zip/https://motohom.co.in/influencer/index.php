<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>Motohom - Rental Luxury Caravan, Campervans and Vanity Vans</title>

    <!-- Fav Icon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.webp">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet"  media="print" onload="this.media='all'">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/color.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preload" href="assets/css/century-gothic-font/CenturyGothic.woff2" as="font" type="font/woff2" crossorigin="anonymous">
    <link rel="preload" href="assets/css/century-gothic-font/GOTHICB0.woff2" as="font" type="font/woff2" crossorigin="anonymous">
    <link rel="preload" href="assets/css/fonts/flaticon.ttf?1df927c" as="font" type="font/ttf" crossorigin="anonymous">
    <link rel="preload" href="assets/css/fonts/fa-light-300.woff2" as="font" type="font/woff2" crossorigin="anonymous">
    <link rel="preload" href="assets/css/fonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin="anonymous">

    <link rel="preload" href="assets/images/banner/1.avif" as="image">
    <link rel="preconnect" href="https://connect.facebook.net">
    <link rel="dns-prefetch" href="https://connect.facebook.net">



    <!-- Meta Pixel Code -->
    <script>
        !function (f, b, e, v, n, t, s) {
            if (f.fbq) return; n = f.fbq = function () {
                n.callMethod ?
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0';
            n.queue = []; t = b.createElement(e); t.async = !0;
            t.src = v; s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1072950017778586');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=1072950017778586&ev=PageView&noscript=1" />
    </noscript>
    <!-- End Meta Pixel Code -->

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-758526398"></script>
    <script> window.dataLayer = window.dataLayer || []; function gtag() { dataLayer.push(arguments); } gtag('js', new Date()); gtag('config', 'AW-758526398'); 
    </script>

    <!-- Event snippet for Submit lead form conversion page
    In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
    <script>
    function gtag_report_conversion(url) {
      var callback = function () {
        if (typeof(url) != 'undefined') {
          window.location = url;
        }
      };
      gtag('event', 'conversion', {
          'send_to': 'AW-758526398/aGcBCN2d-u8ZEL7j2OkC',
          'event_callback': callback
      });
      return false;
    }
    </script>

</head>


<!-- page wrapper -->

<body>

    <div class="boxed_wrapper">





        <!-- main header -->
        <header class="main-header header-style-one">
            <div class="header-lower">
                <div class="logo-box">
                    <figure class="logo"><a href="index.php"><img src="assets/images/logo.png"
                                alt="Make up van Campervan" title="Make up van Campervan"></a></figure>
                </div>
                <div class="outer-box">
                    <div class="menu-area">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#about">About</a></li>
                                    <!-- <li><a href="#gallery">Gallery</a></li> -->
                                    <li><a href="#testimonial">Testimonial</a></li>
                                    <li><a href="#feature">Feature</a></li>
                                    <li><a href="#contact">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="menu-right-content">
                        <div class="support-box">
                            <div class="icon"><a style="color: #ffffff; " href="https://wa.me/+919819655509"
                                    target="_blank"><i class="flaticon-chat"></i></a></div>
                            <span>Chat With Us</span>
                            <h5><a href="https://wa.me/+919819655509" target="_blank">+91-9819655509</a></h5>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-box">
                    <div class="menu-area">
                        <nav class="main-menu clearfix">
                        </nav>
                    </div>
                    <div class="menu-right-content">
                        <div class="support-box">
                            <div class="icon"><i class="flaticon-chat"></i></div>
                            <span>Chat With Us</span>
                            <h5><a href="https://wa.me/+919819655509" target="_blank">+91-9819655509</a></h5>
                        </div>

                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/footer-logo.png"
                            alt="Running vanity van" title="Running vanity van"></a>
                </div>
                <div class="menu-outer">
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><a href="tel:+919819655509">+91-9819655509</a></li>
                        <li><a href="tel:+918369455835">+91-8369455835 </a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="https://twitter.com/motohomcaravans?lang=en" target="_blank"><i
                                    class="fab fa-twitter"></i></a></li>
                        <li><a href="https://m.facebook.com/motohomcaravan/" target="_blank"><i
                                    class="fab fa-facebook-f"></i></a></li>
                        <li><a href=" http://www.youtube.com/@spcustomdesign" target="_blank"><i
                                    class="fab fa-youtube"></i></a></li>
                        <li><a href="https://www.linkedin.com/company/motohom-pvt-ltd/" target="_blank"><i
                                    class="fa-brands fa-linkedin"></i></a></li>
                        <li><a href="https://www.instagram.com/motohom.caravans?igsh=MTdwNnV3MjF3MWN3Mg=="
                                target="_blank"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-section -->
        <section class="banner-section centred">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-1.png);"></div>
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
                <div class="slide-item">
                    <div class="image-layer" style="background-image:url(assets/images/banner/1.avif)"></div>
                    <div class="auto-container" style="position: relative; z-index: -99; visibility: hidden;">
                        <div class="content-box">
                            <span>Join the Summer Adventure</span>
                            <h2>Camping With <br />Friends Gives Joy</h2>
                            <div class="btn-box">
                                <a href="index.php" class="theme-btn btn-one">Discover More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slide-item style-two">
                    <div class="image-layer" style="background-image:url(assets/images/banner/2.avif)"></div>
                    <div class="auto-container" style="position: relative; z-index: -99; visibility: hidden;">
                        <div class="content-box">
                            <span>Join the Summer Adventure</span>
                            <h2>Camping With <br />Friends Gives Joy</h2>
                            <div class="btn-box">
                                <a href="index.php" class="theme-btn btn-one">Discover More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slide-item style-three">
                    <div class="image-layer" style="background-image:url(assets/images/banner/3.avif)"></div>
                    <div class="auto-container" style="position: relative; z-index: -99; visibility: hidden;">
                        <div class="content-box">
                            <span>Join the Summer Adventure</span>
                            <h2>Camping With <br />Friends Gives Joy</h2>
                            <div class="btn-box">
                                <a href="index.php" class="theme-btn btn-one">Discover More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="media-partner">
                <ul class="media-links clearfix">
                    <li>
                        <h6>Follow on social media</h6>
                    </li>
                    <li><a href="https://twitter.com/motohomcaravans?lang=en" target="_blank"><i
                                    class="fab fa-twitter"></i></a></li>
                        <li><a href="https://m.facebook.com/motohomcaravan/" target="_blank"><i
                                    class="fab fa-facebook-f"></i></a></li>
                        <li><a href=" http://www.youtube.com/@spcustomdesign" target="_blank"><i
                                    class="fab fa-youtube"></i></a></li>
                        <li><a href="https://www.linkedin.com/company/motohom-pvt-ltd/" target="_blank"><i
                                    class="fa-brands fa-linkedin"></i></a></li>
                        <li><a href="https://www.instagram.com/motohom.caravans?igsh=MTdwNnV3MjF3MWN3Mg=="
                                target="_blank"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </section>
        <!-- banner-section end -->


        <section class="qotation-form about-style-three">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 form-column">
                        <div class="sec-title">
                            <span class="sub-title">Plan Your Journey</span>
                            <h2>Step By Step</h2>
                        </div>
                        <div class="form-inner">
                            <form id="contact-form" class="default-form" novalidate="novalidate">
                                <div class="row clearfix">
                                    <!-- First Name -->
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input id="firstname" type="text" name="firstname" placeholder="First Name" required=""
                                            aria-required="true">
                                    </div>

                                    <!-- Last Name -->
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input id="lastname" type="text" name="lastname" placeholder="Last Name" required=""
                                            aria-required="true">
                                    </div>

                                    <!-- Phone -->
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input id="phone" type="text" name="phone" placeholder="Phone" required=""
                                            aria-required="true">
                                    </div>

                                    <!-- Email -->
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input id="email" type="email" name="email" placeholder="Email Address" required=""
                                            aria-required="true">
                                    </div>

                                    <!-- Select Location -->
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <select id="location" name="location" required="" aria-required="true">
                                            <option value="" disabled="" selected="">Select Location</option>
                                            <option value="Mumbai">Mumbai</option>
                                            <option value="Hyderabad">Hyderabad</option>
                                            <option value="Vadodara">Vadodara</option>
                                            <option value="Surat">Surat</option>
                                            <option value="Ahmedabad">Ahmedabad</option>
                                            <option value="Bangalore">Bangalore</option>
                                            <option value="Delhi">Delhi</option>
                                        </select>
                                    </div>

                                    <!-- Select Caravan -->
                                    <!-- <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <select id="caravan_class" name="caravan_class" required="" aria-required="true">
                                            <option value="" disabled="" selected="">Select Caravan</option>
                                            <option value="T Class Caravan">T Class Caravan</option>
                                            <option value="U Class Caravan">U Class Caravan</option>
                                            <option value="M Class Caravan">M Class Caravan</option>
                                            <option value="V Class Caravan">V Class Caravan</option>
                                        </select>
                                    </div> -->

                                    <!-- Submit Button -->
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn mr-0">
                                        <button class="theme-btn btn-one" type="submit"
                                            name="submit-form"><span>Submit</span></button>
                                    </div>
                                </div>
                            </form>


                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_three">
                            <div class="image-box">
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 single-image">
                                        <figure class="image"><img src="assets/images/resource/fs.avif"
                                                alt="Vanity for tour purpose" title="Vanity for tour purpose" ></figure>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 single-image">
                                        <figure class="image"><img src="assets/images/resource/fl.avif"
                                                alt="Vanity for travel purpose" title="Vanity for travel purpose" ></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <!-- client-section -->
        <section class="client-section">
            <div class="auto-container">
                <div class="title-text centred">
                    <span>Trusted By</span>
                </div>
                <div class="three-item-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                    <figure class="clients-logo"><a href="https://www.instagram.com/theshilpashetty/?hl=en"><img src="assets/images/clients/clients-1.png"
                                alt="Vanity van for celebrity" title="Vanity van for celebrity"></a></figure>
                    <figure class="clients-logo"><a href="https://www.instagram.com/bharti.laughterqueen/?hl=en"><img src="assets/images/clients/clients-2.png"
                                alt="Election van on hire" title="Election van on hire"></a></figure>
                    <figure class="clients-logo"><a href="https://www.instagram.com/suniel.shetty/?hl=en"><img src="assets/images/clients/clients-3.png"
                                alt="Election van on rent" title="Election van on rent"></a></figure>

                </div>
            </div>
        </section>
        <!-- client-section end -->




        <!-- about-style-two -->
        <section class="about-style-two" id="about">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_two">
                            <div class="image-box">
                                <div class="shape">
                                    <div class="shape-1"></div>
                                    <div class="shape-2"></div>
                                </div>
                                <figure class="image"><img src="assets/images/resource/about.avif"
                                        alt="Vanity van on rent" title="Vanity van on rent"></figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_three">
                            <div class="content-box">
                                <div class="sec-title">
                                    <span class="sub-title">Welcome to Motohom Caravans</span>
                                    <h2>Experience Unique Camper Van Adventures</h2>
                                </div>
                                <div class="text">
                                    <p>Born in Mumbai, Motohom delivers camper vans for seamless travel across India,
                                        combining transport and comfort.</p>
                                </div>
                                <div class="inner-box">
                                    <div id="open-form-btn" class="inner">
                                        <div class="icon-box"><i class="fa-solid fa-caravan"></i></div>
                                        <span>Join Our <br />Motohom Journey</span>
                                    </div>
                                    <ul class="list-style-one clearfix">
                                        <li>Verticals: Tourism, Corporate, Film Industry, Mobility Solutions and Pet Tourism</li>
                                        <li>Recognized by Govt. of India  as Maharastra and Uttar Pradesh's official caravan vendor</li>
                                    </ul>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-style-two end -->

        <!-- gallery-style-two -->
        <!-- <section class="gallery-style-two" id="gallery">
            <div class="outer-container">
                <div class="gallery-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/5.png" alt="Van with washroom" title="Van with washroom">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/5.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/1.png" alt="Mobile dressing room for events" title="Mobile dressing room for events">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/1.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/2.png" alt="Premium class RV rental" title="Premium class RV rental">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/2.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/3.png" alt="Mobile production unit van" title="Mobile production unit van"> 
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/3.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/6.png" alt="Tailor-made celebrity travel van" title="Tailor-made celebrity travel van">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/6.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/7.png" alt="Election campaign mobile office" title="Election campaign mobile office">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/7.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/8.png" alt="Adventure-ready luxury van" title="Adventure-ready luxury van"> 
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/8.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/9.png" alt="Professional makeup van hire" title="Professional makeup van hire">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/9.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="gallery-block-two">
                        <div class="inner-box">
                            <figure class="image"><img src="assets/images/gallery/10.png" alt="Comfortable long-distance travel van" title="Comfortable long-distance travel van">
                            </figure>
                            <div class="view-btn"><a href="assets/images/gallery/10.png" class="lightbox-image"
                                    data-fancybox="gallery"><i class="flaticon-plus"></i></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- gallery-style-two end -->


        <!-- testimonial-style-two -->
        <section class="testimonial-style-two" id="testimonial">
            <div class="bg-layer" style="background-image: url(assets/images/background/testibg.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 title-column">
                        <div class="sec-title">
                            <span class="sub-title">Client Diaries</span>
                            <h2>Hear from Our Happy Campers!</h2>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 inner-column">
                        <div class="inner-content">
                            <div class="two-item-carousel owl-carousel owl-theme owl-nav-none">
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>We recently had the pleasure of renting a
                                            motohom caravan, and we couldn't be happier
                                            with our experience! From start to finish, the
                                            service was outstanding.
                                            What really impressed us was their unique
                                            experience. We watched our favourite movie in
                                            the open sky at lakeside.
                                            Thanks to Motohom team! Will surely book it
                                            again!</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi1.png"
                                                alt="Bus with sleeping bed" title="Bus with sleeping bed"></figure>
                                        <span class="name">Kajal Waghmare</span>
                                    </div>
                                </div>
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>We had a great experience with Motohom
                                            Caravans . Service was luxurious and amazing.
                                            They provide service of bbq and tents also. They
                                            make your weekend</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi2.png"
                                                alt="Executive road travel van rental" title="Executive road travel van rental"></figure>
                                        <span class="name">Neeraj Singh</span>
                                    </div>
                                </div>
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>Just wow.Loved the Ambience.Very well
                                            organised space.lt is completely hotel on wheels
                                            and provides a very comy ride.l travelled from
                                            Lucknow to Ayodhya with my friends and had an
                                            amazing time in the vanity.</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi3.png"
                                                alt="Custom luxury tour bus rental" title="Custom luxury tour bus rental"></figure>
                                        <span class="name">The Lost Traveller</span>
                                    </div>
                                </div>
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>We hired a 40 ft caravan & planned a surprise day
                                            trip to Lonavala to celebrate bday of a friend. It
                                            was an exceptional experience. Will surely
                                            recommend. Thanks Motohom</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi4.png"
                                                alt="Special event RV rental" title="Special event RV rental"></figure>
                                        <span class="name">Himanshu Vyapak</span>
                                    </div>
                                </div>
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>India's first campervan and caravan startup
                                            which tied up with MTDC, it's an amazing
                                            concept.all the very best MotohoM and team.</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi5.png"
                                                alt="Mobile film production van hire" title="Mobile film production van hire"></figure>
                                        <span class="name">Suyog Mestry</span>
                                    </div>
                                </div>
                                <div class="testimonial-content">
                                    <div class="text">
                                        <p>What a fantastic service provided by motohom.
                                            The caravan was filled with luxury, very
                                            experienced deivers and a safe trip during covid
                                            times. Truly recommend travelling with them for a
                                            unique experience with your family..spl thanks to
                                            Satya for coordinating day in and out to make this
                                            a beautiful trip</p>
                                    </div>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testi6.png"
                                                alt="Deluxe camper for road trips" title="Deluxe camper for road trips"></figure>
                                        <span class="name">Moushmi Mohan</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial-style-two end -->


        <!-- feature-style-two -->
        <section id="feature" class="feature-style-two centred">
            <div class="auto-container">
                <div class="feature-grid">
                    <div class=" feature-block">
                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure
                                    class="image-box single-item-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                                    <img src="assets/images/resource/t.avif" alt="Camper van on hire" title="Camper van on hire" width="300" height="200">
                                    <img src="assets/images/resource/t1.avif" alt="Luxury entertainment bus rental" title="Luxury entertainment bus rental" width="300" height="200">
                                    <img src="assets/images/resource/t2.avif" alt="Mobile green room hire" title="Mobile green room hire" width="300" height="200">
                                    <img src="assets/images/resource/t3.avif" alt="Touring artist's vanity van" title="Touring artist's vanity van" width="300" height="200">
                                </figure>
                                <div class="lower-content">
                                    <h3><a>T Class Caravan</a></h3>
                                    <ul>
                                        <li><strong>Per day rental</strong>: ₹18,000 (up to 350 km/day) excluding fuel tolls and GST.</li>
                                        <li><strong>Per km rental</strong>: ₹70/km (for distances exceeding 350 km/day) Including fuel.
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" feature-block">
                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure
                                    class="image-box single-item-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                                    <img src="assets/images/resource/u.avif" alt="Camper van on rent" title="Camper van on rent" width="300" height="200">
                                    <img src="assets/images/resource/u1.avif" alt="VIP transport van rental" title="VIP transport van rental" width="300" height="200">
                                    <img src="assets/images/resource/u2.avif" alt="Mobile event management van" title="Mobile event management van" width="300" height="200">
                                    <img src="assets/images/resource/u3.avif" alt="High-end campaign vehicle hire" title="High-end campaign vehicle hire" width="300" height="200">
                                </figure>
                                <div class="lower-content">
                                    <h3><a>U Class Caravan</a></h3>
                                    <ul>
                                        <li><strong>Per day rental</strong>: ₹21,000 (up to 350 km/day) excluding fuel tolls and GST.</li>
                                        <li><strong>Per km rental</strong>: ₹85/km (for distances exceeding 350 km/day) Including fuel.
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" feature-block">
                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure
                                    class="image-box single-item-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                                    <img src="assets/images/resource/m.avif" alt="Vanity van for elder people travel" title="Vanity van for elder people travel" width="300" height="200">
                                    <img src="assets/images/resource/m1.avif" alt="Celebrity tour bus rental" title="Celebrity tour bus rental" width="300" height="200">
                                    <img src="assets/images/resource/m2.avif" alt="Customized road trip van" title="Customized road trip van" width="300" height="200">
                                    <img src="assets/images/resource/m3.avif" alt="Elder-accessible motorhome rental" title="Elder-accessible motorhome rental" width="300" height="200">
                                </figure>
                                <div class="lower-content">
                                    <h3><a>M Class Caravan</a></h3>
                                    <ul>
                                        <li><strong>Per day rental</strong>: ₹30,000 (up to 350 km/day) excluding fuel tolls and GST.</li>
                                        <li><strong>Per km rental</strong>: ₹110/km (for distances exceeding 350 km/day) Including fuel.
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" feature-block">
                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure
                                    class="image-box single-item-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                                    <img src="assets/images/resource/v.avif" alt="Luxury van for sleeping" title="Luxury van for sleeping" width="300" height="200">
                                    <img src="assets/images/resource/v1.avif" alt="Luxurious travel coach hire" title="Luxurious travel coach hire" width="300" height="200">
                                    <img src="assets/images/resource/v2.avif" alt="Event-ready camper van rental" title="Event-ready camper van rental" width="300" height="200">
                                    <img src="assets/images/resource/v3.avif" alt="Roadshow vehicle on rent" title="Roadshow vehicle on rent" width="300" height="200">
                                </figure>
                                <div class="lower-content">
                                    <h3><a>V Class Caravan</a></h3>
                                    <ul>
                                        <li><strong>Per day rental</strong>: ₹45,000 (up to 350 km/day) excluding fuel tolls and GST.</li>
                                        <li><strong>Per km rental</strong>: ₹160/km (for distances exceeding 350 km/day) Including fuel.
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature-style-two end -->


        <!-- video-section -->
        <section class="video-section">
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}'
                style="background-image: url(assets/images/background/video-bg.jpg);"></div>
            <div class="auto-container">
                <div class="inner-box">
                    <div class="sec-title light">
                        <span class="sub-title">Find the Perfect Camper for You</span>
                        <h2>Create Lasting Memories on Your Adventure</h2>
                    </div>
                    <div class="video-btn">
                        <a href="https://youtu.be/Vz-BiCMTsAc?si=PRYBCNWSivMvStrF" class="lightbox-image"
                            data-caption="" style="background-image: url(assets/images/shape/shape-7.png);"><i
                                class="fas fa-play"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- video-section end -->


        <div class="container-works auto-container about-style-two">
            <div class="content col-lg-6 col-md-12 col-sm-12 content-column">
                <!-- <h1>How Motohom Works</h1> -->
                <div class="sec-title">
                    <span class="sub-title">Step-by-Step Process</span>
                    <h2>How Motohom Works</h2>
                </div>
                <div class="step">
                    <img alt="Icon of a location pin" title="Icon of a location pin" 
                        src="assets/images/resource/1.png"  width="50" height="50">
                    <div>
                        <h2>Select the Location</h2>
                        <p>Choose the location where you want to start your journey.</p>
                    </div>
                </div>
                <div class="step">
                    <img alt="Icon of a caravan" title="Icon of a location pin" 
                        src="assets/images/resource/2.png"  width="50" height="50">
                    <div>
                        <h2>Select the caravan</h2>
                        <p>Pick the caravan that suits your needs and preferences.</p>
                    </div>
                </div>
                <div class="step">
                    <img alt="Icon of personal details" title="Icon of personal details" 
                        src="assets/images/resource/3.png"  width="50" height="50">
                    <div>
                        <h2>Enter personal details</h2>
                        <p>Provide your personal details to proceed with the booking.</p>
                    </div>
                </div>
                <div class="step">
                    <img alt="Icon of a quotation" title="Icon of a quotation" 
                        src="assets/images/resource/4.png"  width="50" height="50">
                    <div>
                        <h2>Get quotation</h2>
                        <p>Receive a quotation for your selected caravan and trip details.</p>
                    </div>
                </div>
                <div class="step">
                    <img alt="Icon of a map" title="Icon of a map" 
                        src="assets/images/resource/5.png"  width="50" height="50">
                    <div>
                        <h2>Hit the road</h2>
                        <p>Motohom offers a marketplace where we help facilitate communication and connect you with the
                            van owner. You can easily pick up your camper van or have it delivered directly to you.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                <div class="image_block_two how">
                    <div class="image-box">
                        <div class="shape">
                            <div class="shape-1"></div>
                            <div class="shape-2"></div>
                        </div>
                        <figure class="image"><img src="assets/images/resource/works.avif"
                                alt="Van with kitchen and toilet" title="Van with kitchen and toilet"></figure>
                    </div>
                </div>
            </div>
        </div>


        


        <section class="weare-section bg-color-2">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-11.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 title-column">
                        <div class="sec-title">
                            <span class="sub-title">Get to Know Us</span>
                            <h2>We’re India’s Luxury Caravan Service</h2>
                            <p>Motohom redefines travel in India with state-of-the-art camper vans, combining the
                                freedom of mobility with the comfort of home. Recognized by the Government of India and
                                as Maharashtra’s official caravan vendor, we proudly serve tourism, corporate, and film
                                industries. Experience India like never before—explore, relax, and make memories, all
                                from the comfort of a Motohom camper.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_four">
                            <div class="content-box">
                                <figure class="image"><img src="assets/images/resource/weare-1.png"
                                        alt="Moving vanity van" title="Moving vanity van" width="300" height="200" loading="lazy"></figure>
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 progress-column">
                                        <div class="progress-inner">
                                            <div class="progress-box">
                                                <div class="piechart" data-fg-color="#ff6f29" data-value=".98"></div>
                                                <span class="count-text">98%</span>
                                            </div>
                                            <div class="text">
                                                <h4>People Satisfied</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 progress-column">
                                        <div class="progress-inner">
                                            <div class="progress-box">
                                                <div class="piechart" data-fg-color="#ffbf37" data-value="1"></div>
                                                <span class="count-text">100%</span>
                                            </div>
                                            <div class="text">
                                                <h4>Tours Completed</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>





        <section id="contact" class="contact-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-5 col-md-12 col-sm-12 content-column">
                        <div class="content_block_six">
                            <div class="content-box">
                                <div class="sec-title">
                                    <span class="sub-title">Contact With Us</span>
                                    <h2>Drop a Message</h2>
                                    <p>Get in touch with us for any inquiries, support, or partnership opportunities.
                                        Let us help make your adventure unforgettable!
                                    </p>
                                </div>
                                <div class="inner-box">
                                    <div class="single-item">
                                        <div class="icon-box"><i class="flaticon-open-envelope"></i></div>
                                        <p>Send Email</p>
                                        <h3><a href="mailto:hello@motohom.com">hello@motohom.com</a></h3>
                                    </div>
                                    <div class="single-item">
                                        <div class="icon-box"><i class="flaticon-phone"></i></div>
                                        <p>Call 24/7</p>
                                        <h3><a href="tel:+918369455835">+91-8369455835</a></h3>
                                        <h3><a href="tel:+919819655509">+91-9819655509</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12 col-sm-12 content-column step-form">
                        <!-- <div class="sec-title">
                            <span class="sub-title">Plan Your Journey</span>
                            <h2>Step By Step</h2>
                        </div> -->
                        <div class="card">
                            <!-- <h2 id="heading"></h2> -->
                            <p>Fill out all fields to proceed to the next step</p>
                            <form id="msform" method="POST">
                                <!-- Progress Bar -->
                                <ul id="progressbar">
                                    <li class="active" id="location">Location</li>
                                    <!-- <li id="caravan">Caravan</li> -->
                                    <li id="personal">Details</li>
                                    <li id="confirm">Finish</li>
                                </ul>
                                <div class="progress-bar">
                                    <div class="progress-bar-inner"></div>
                                </div>
                                <!-- Steps -->
                                <fieldset class="active">
                                    <div class="form-card">
                                        <label for="location">Choose Location</label>
                                        <select name="location" id="locationField" required>
                                            <option value="" disabled selected>Select Location</option>
                                            <option value="Mumbai">Mumbai</option>
                                            <option value="Hyderabad">Hyderabad</option>
                                            <option value="Pune">Pune</option>
                                            <option value="Vadodara">Vadodara</option>
                                            <option value="Surat">Surat</option>
                                            <option value="Ahmedabad">Ahmedabad</option>
                                            <option value="Bangalore">Bangalore</option>
                                            <option value="Delhi">Delhi</option>
                                        </select>
                                    </div>
                                    <button type="button" class="next action-button">Next</button>
                                </fieldset>
                                <!-- <fieldset>
                                    <div class="form-card">
                                        <label for="caravan">Choose Caravan</label>
                                        <select name="caravan" id="caravanField" required>
                                            <option value="" disabled selected>Select Caravan</option>
                                            <option value="T class caravan">T class caravan</option>
                                            <option value="U class caravan">U class caravan</option>
                                            <option value="M class caravan">M class caravan</option>
                                            <option value="V class caravan">V class caravan</option>
                                        </select>
                                    </div>
                                    <button type="button" class="previous action-button-previous">Previous</button>
                                    <button type="button" class="next action-button">Next</button>
                                </fieldset> -->
                                <fieldset>
                                    <div class="form-card">
                                        <label for="fname">First Name</label>
                                        <input type="text" id="fname" name="fname" placeholder="First Name" required>
                                        <label for="lname">Last Name</label>
                                        <input type="text" id="lname" name="lname" placeholder="Last Name" required>
                                        <label for="phone">Phone</label>
                                        <input type="text" id="phone" name="phone" placeholder="Phone Number" required>
                                        <label for="email">Email</label>
                                        <input type="email" id="email" name="email" placeholder="Email Address"
                                            required>
                                    </div>
                                    <button type="button" class="previous action-button-previous">Previous</button>
                                    <button type="button" class="next action-button">Next</button>
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="success-message">Success!</h2>
                                        <p class="quote">"The best journeys answer questions that in the beginning, you
                                            didn’t even
                                            think to ask."</p>
                                    </div>
                                    <button type="button" class="previous action-button-previous">Previous</button>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- google-map-section -->
        <section class="google-map-section">
            <div class="shape" style="background-image: url(assets/images/shape/shape-9.png);"></div>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3692.875765172274!2d74.537598!3d22.244792!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7a91c4594566b%3A0xddda4ee3ab4d8!2sMotohom!5e0!3m2!1sen!2sin!4v1731569182966!5m2!1sen!2sin"
                width="100%" height="550" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </section>

        <!-- google-map-section end -->


        <!-- main-footer -->
        <footer class="main-footer pt-0">
            <div class="auto-container">
                <div class="footer-top">
                    <div class="top-inner">
                        <div class="text">
                            <h5>Send Email</h5>
                            <h3><a href="mailto:hello@motohom.com">hello@motohom.com</a></h3>
                        </div>
                        <figure class="footer-logo"><a href="index.php"><img src="assets/images/footer-logo.png"
                                    alt="Caravan" title="Caravan"></a></figure>
                        <div class="text">
                            <h5>Call 24/7</h5>
                            <h3><a href="tel:+918369455835">+91-8369455835 </a></h3>
                            <h3><a href="tel:+919819655509">+91-9819655509</a></h3>
                        </div>
                    </div>
                </div>
                <div class="widget-section">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <!-- <div class="widget-title">
                                    <h4>Explore</h4>
                                </div> -->
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="index.php">Make up van</a></li>
                                        <li><a href="index.php">Running vanity van</a></li>
                                        <li><a href="index.php">Vanity for tour purpose</a></li>
                                        <li><a href="index.php">Vanity for travel purpose</a></li>
                                        <li><a href="index.php">Vanity van for celebrity</a></li>
                                        <li><a href="index.php">Election van on hire</a></li>
                                        <li><a href="index.php">Election van on rent</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <!-- <div class="widget-title">
                                    <h4>Activities</h4>
                                </div> -->
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="index.php">Vanity van on rent</a></li>
                                        <li><a href="index.php">Camper van on hire</a></li>
                                        <li><a href="index.php">Camper van on rent</a></li>
                                        <li><a href="index.php">Vanity van for elder people travel</a></li>
                                        <li><a href="index.php">Luxury van for sleeping</a></li>
                                        <li><a href="index.php">Van with kitchen and toilet</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <!-- <div class="widget-title">
                                    <h4>Activities</h4>
                                </div> -->
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="index.php">Van with washroom</a></li>
                                        <li><a href="index.php">Bus with sleeping bed</a></li>
                                        <li><a href="index.php">Moving vanity van</a></li>
                                        <li><a href="index.php">Vanity van on hire</a></li>
                                        <li><a href="index.php">Caravan</a></li>
                                        <li><a href="index.php">Campervan</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget contact-widget">
                                <div class="widget-title">
                                    <h4>Social Links</h4>
                                </div>
                                <div class="widget-content">
                                    <!-- <p>60 road, broklyn golden street new york. USA</p> -->
                                    <ul class="social-links clearfix">
                                        <li><a href="https://twitter.com/motohomcaravans?lang=en" target="_blank"><i
                                                    class="fab fa-twitter"></i></a></li>
                                        <li><a href="https://m.facebook.com/motohomcaravan/" target="_blank"><i
                                                    class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=" http://www.youtube.com/@spcustomdesign" target="_blank"><i
                                                    class="fab fa-youtube"></i></a></li>
                                        <li><a href="https://www.linkedin.com/company/motohom-pvt-ltd/"
                                                target="_blank"><i class="fa-brands fa-linkedin"></i></a></li>
                                        <li><a href="https://www.instagram.com/motohom.caravans?igsh=MTdwNnV3MjF3MWN3Mg=="
                                                target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="footer-bottom centred">
                <div class="auto-container">
                    <div class="copyright">
                        <p>&copy; Copyright 2024 Designed & Develped by <a href="https://www.digitalmarketinng.com/"
                                target="_blank">Oh! Puhleeez</a></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- main-footer end -->


        <!-- scroll to top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fal fa-long-arrow-up"></i>
        </button>



        <!-- Popup Form Structure -->
        <div id="popup-form" class="popup-form">
            <div class="popup-content">
                <span id="close-form-btn" class="close-btn">&times;</span>
                <form id="contact-form-2" class="default-form" novalidate="novalidate">
                    <div class="row clearfix">
                        <!-- First Name -->
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input id="firstname" type="text" name="firstname" placeholder="First Name" required=""
                                aria-required="true">
                        </div>

                        <!-- Last Name -->
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input id="lastname" type="text" name="lastname" placeholder="Last Name" required="" aria-required="true">
                        </div>

                        <!-- Phone -->
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input id="phone" type="text" name="phone" placeholder="Phone" required="" aria-required="true">
                        </div>

                        <!-- Email -->
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input id="email" type="email" name="email" placeholder="Email Address" required=""
                                aria-required="true">
                        </div>

                        <!-- Select Location -->
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                            <select id="location" name="location" required="" aria-required="true">
                                <option value="" disabled="" selected="">Select Location</option>
                                <option value="Mumbai">Mumbai</option>
                                <option value="Hyderabad">Hyderabad</option>
                                <option value="Vadodara">Vadodara</option>
                                <option value="Surat">Surat</option>
                                <option value="Ahmedabad">Ahmedabad</option>
                                <option value="Bangalore">Bangalore</option>
                                <option value="Delhi">Delhi</option>
                            </select>
                        </div>

                        <!-- Select Caravan -->
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                            <select id="caravan_class" name="caravan_class" required="" aria-required="true">
                                <option value="" disabled="" selected="">Select Caravan</option>
                                <option value="T Class Caravan">T Class Caravan</option>
                                <option value="U Class Caravan">U Class Caravan</option>
                                <option value="M Class Caravan">M Class Caravan</option>
                                <option value="V Class Caravan">V Class Caravan</option>
                            </select>
                        </div>

                        <!-- Submit Button -->
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn mr-0">
                            <button class="theme-btn btn-one" type="submit"
                                name="submit-form"><span>Submit</span></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="open-form-btn">
        <a class="enquire-now-btn">Enquire Now</a>
    </div>

    <!-- WhatsApp Button -->
    <a href="https://wa.me/+919819655509" target="_blank" class="whatsapp-button">
        <img src="assets/images//WhatsApp.svg" alt="WhatsApp" title="WhatsApp">
    </a>



    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js" ></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/parallax-scroll.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/jquery.countTo.js"></script>
    <script src="assets/js/pagenav.js"></script>

    <!-- map script -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-CE0deH3Jhj6GN4YvdCFZS7DpbXexzGU"></script>
    <script src="assets/js/gmaps.js"></script>
    <script src="assets/js/map-helper.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const forms = document.querySelectorAll('form.default-form'); // Select all forms with the class "default-form"

            forms.forEach((form) => {
                form.addEventListener('submit', function (e) {
                    e.preventDefault(); // Prevent default form submission

                    const formData = new FormData(form);

                    fetch('submit_contact_form.php', {
                        method: 'POST',
                        body: formData
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            if (data.status === 'success') {
                                alert('Form submitted successfully!');
                                form.reset(); // Reset the form after success
                            } else {
                                alert('Error: ' + data.message);
                            }
                        })
                        .catch((error) => {
                            console.error('Error:', error);
                            alert('An error occurred while submitting the form.');
                        });
                });
            });
        });

    </script>



    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let current_fs, next_fs, previous_fs;
            let current = 1;
            const totalSteps = document.querySelectorAll("fieldset").length;
            const progressBarItems = document.querySelectorAll("#progressbar li");

            const setProgressBar = (step) => {
                const percent = (step / totalSteps) * 100;
                document.querySelector('.progress-bar-inner').style.width = `${percent}%`;

                // Update the active step on the progress bar
                progressBarItems.forEach((item, index) => {
                    if (index < step) {
                        item.classList.add('active');
                    } else {
                        item.classList.remove('active');
                    }
                });
            };

            const validateStep = () => {
                const activeFieldset = document.querySelector("fieldset.active");
                const inputs = activeFieldset.querySelectorAll("input, select");
                for (const input of inputs) {
                    if (!input.value) {
                        input.focus();
                        alert("Please fill out all required fields.");
                        return false;
                    }
                }
                return true;
            };

            const togglePreviousButtonInLastStep = () => {
                const currentFieldset = document.querySelector("fieldset.active");
                const previousButton = currentFieldset.querySelector(".previous");

                if (currentFieldset.nextElementSibling === null && previousButton) {
                    previousButton.style.display = "none"; // Hide the previous button on the last step
                } else if (previousButton) {
                    previousButton.style.display = "inline-block"; // Show the previous button in other steps
                }
            };

            const updateNextButtonText = () => {
                const currentFieldset = document.querySelector("fieldset.active");
                const nextButton = currentFieldset.querySelector(".next");

                if (nextButton) {
                    if (document.querySelectorAll("fieldset")[1].classList.contains("active")) {
                        nextButton.textContent = "Get Quotation"; // Update text on the 3rd step
                    } else {
                        nextButton.textContent = "Next"; // Default text for other steps
                    }
                }
            };

            document.querySelectorAll('.next').forEach(button => {
                button.addEventListener('click', () => {
                    if (!validateStep()) return;

                    current_fs = button.closest('fieldset');
                    next_fs = current_fs.nextElementSibling;

                    // Handle final step (Get Quotation button click)
                    if (document.querySelectorAll("fieldset")[1].classList.contains("active")) {
                        const form = document.getElementById('msform'); // Form element
                        const formData = new FormData(form); // Gather all form data

                        fetch('submit_form.php', {
                            method: 'POST',
                            body: formData
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === 'success') {
                                    // Move to success step
                                    current_fs.classList.remove('active');
                                    next_fs.classList.add('active');
                                    current++;
                                    setProgressBar(current);
                                    togglePreviousButtonInLastStep();
                                    updateNextButtonText();
                                } else {
                                    alert('Error: ' + data.message);
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                alert('An error occurred while submitting the form.');
                            });

                        return; // Prevent moving to the next step until submission is successful
                    }

                    if (next_fs) {
                        current_fs.classList.remove('active');
                        next_fs.classList.add('active');

                        current++;
                        setProgressBar(current);
                        togglePreviousButtonInLastStep();
                        updateNextButtonText();
                    }
                });
            });

            document.querySelectorAll('.previous').forEach(button => {
                button.addEventListener('click', () => {
                    current_fs = button.closest('fieldset');
                    previous_fs = current_fs.previousElementSibling;

                    if (previous_fs) {
                        current_fs.classList.remove('active');
                        previous_fs.classList.add('active');

                        current--;
                        setProgressBar(current);
                        togglePreviousButtonInLastStep();
                        updateNextButtonText();
                    }
                });
            });

            setProgressBar(current);
            togglePreviousButtonInLastStep(); // Initial check for the last step
            updateNextButtonText(); // Initial button text check
        });
    </script>


</body><!-- End of .page_wrapper -->

</html>